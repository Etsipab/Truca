import os

def lister_fichiers_dossiers():
    # Récupérer le chemin du répertoire actuel
    chemin_actuel = os.getcwd()

    # Liste des noms de fichiers et de dossiers dans le répertoire actuel
    fichiers_dossiers = os.listdir(chemin_actuel)

    # Imprimer chaque nom de fichier ou de dossier
    for element in fichiers_dossiers:
        print(element)

if __name__ == "__main__":
    lister_fichiers_dossiers()

lister_fichiers_dossiers()