#import os
#print(dir())


import os
cwd = os.getcwd()  # Get the current working directory (cwd)
print(cwd)
#files = os.listdir(cwd)  # Get all the files in that directory
#print("Files in %r: %s" % (cwd, files))


trouvée =True
try:
    fichier = open("/data.txt", "r")
except FileNotFoundError:
    print("Le fichier data.txt est introuvable.")
    trouvée =False

if trouvée :
    text=fichier.read().split('\n')
    for line in text :
        print (line)